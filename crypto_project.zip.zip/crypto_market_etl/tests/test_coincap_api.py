import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.extract.coincap_api import CoinCapConnector

class TestCoinCapConnector(unittest.TestCase):

    @patch('src.extract.coincap_api.requests.get')
    def test_fetch_assets_success(self, mock_get):
        # Mock successful response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'data': [{'id': 'bitcoin', 'priceUsd': '50000'}]}
        mock_get.return_value = mock_response

        connector = CoinCapConnector()
        data = connector.fetch_assets()

        self.assertIsNotNone(data)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]['id'], 'bitcoin')

    @patch('src.extract.coincap_api.requests.get')
    def test_fetch_assets_retry(self, mock_get):
        # Mock failure then success
        mock_response_fail = MagicMock()
        mock_response_fail.status_code = 429
        
        mock_response_success = MagicMock()
        mock_response_success.status_code = 200
        mock_response_success.json.return_value = {'data': []}

        mock_get.side_effect = [mock_response_fail, mock_response_success]

        connector = CoinCapConnector(max_retries=2, backoff_factor=0) # Instant retry
        data = connector.fetch_assets()

        self.assertIsNotNone(data)
        self.assertEqual(mock_get.call_count, 2)

    def test_prepare_for_bronze(self):
        connector = CoinCapConnector()
        raw_data = [{'id': 'bitcoin', 'price': 50000}]
        
        prepared = connector.prepare_for_bronze(raw_data)
        
        self.assertEqual(len(prepared), 1)
        self.assertEqual(prepared[0]['asset_id_raw'], 'bitcoin')
        self.assertIn('ingestion_timestamp', prepared[0])
        self.assertIn('payload', prepared[0])

if __name__ == '__main__':
    unittest.main()

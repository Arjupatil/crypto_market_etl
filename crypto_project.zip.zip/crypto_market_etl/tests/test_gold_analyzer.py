import unittest
from unittest.mock import MagicMock
from src.analyze.aggregations import GoldAnalyzer
from pyspark.sql import SparkSession

class TestGoldAnalyzer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Initialize a local SparkSession for testing
        cls.spark = SparkSession.builder \
            .master("local[1]") \
            .appName("TestGoldAnalyzer") \
            .getOrCreate()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def setUp(self):
        self.analyzer = GoldAnalyzer(self.spark)

    def test_calculate_anomalies(self):
        # Create test data
        data = [
            ("bitcoin", "BTC", 50000.0),
            ("bitcoin", "BTC", 51000.0),
            ("bitcoin", "BTC", 49000.0),
            ("bitcoin", "BTC", 100000.0) # Anomaly!
        ]
        columns = ["asset_id", "symbol", "price_usd"]
        df = self.spark.createDataFrame(data, columns)

        # Run anomaly detection
        anomalies = self.analyzer.calculate_anomalies(df, threshold=1.0) # Lower threshold for small data
        
        # Verify
        result = anomalies.collect()
        self.assertTrue(len(result) > 0)
        self.assertEqual(result[0]['asset_id'], "bitcoin")
        # The 100k price should be an anomaly
        self.assertTrue(any(row['price_usd'] == 100000.0 for row in result))

if __name__ == '__main__':
    unittest.main()

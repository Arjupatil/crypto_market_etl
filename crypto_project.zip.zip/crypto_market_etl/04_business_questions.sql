-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 4️⃣ SQL Analytics & Business Insights
-- MAGIC **Goal**: Run ad-hoc queries to answer interview-style business questions using the Gold layer.

-- COMMAND ----------

-- QUESTION 1: Top 10 High Volatility Coins
-- Explanation: Users want to know which coins are riskiest (highest standard deviation relative to price).
-- We use the Coefficient of Variation (Volatility Index) calculated in Gold.

SELECT 
  symbol, 
  ROUND(volatility_index, 4) as volatility_score, 
  ROUND(avg_price_24h, 2) as avg_price,
  ROUND(price_std_dev_24h, 4) as std_dev
FROM gold_volatility
ORDER BY volatility_index DESC
LIMIT 10;

-- COMMAND ----------

-- QUESTION 2: Coins with Unusual Volume Spikes
-- Explanation: Identify coins where recent 24h volume is significantly higher than market cap imply high turnover/speculation.
-- Logic: Volume / Market Cap Ratio > 0.5 (50% of value traded in 24h)

SELECT 
  s.symbol, 
  s.name, 
  ROUND(s.volume_usd_24h, 0) as volume_24h, 
  ROUND(s.marketCapUsd, 0) as market_cap,
  ROUND(s.volume_usd_24h / s.marketCapUsd, 2) as turnover_ratio
FROM silver_assets s
WHERE s.ingestion_timestamp = (SELECT MAX(ingestion_timestamp) FROM silver_assets)
  AND s.marketCapUsd > 1000000 -- Filter out micro-caps to avoid noise
  AND (s.volume_usd_24h / s.marketCapUsd) > 0.5
ORDER BY turnover_ratio DESC;

-- COMMAND ----------

-- QUESTION 3: Daily Market Summary
-- Explanation: What is the total market cap and volume of the entire crypto market right now?

SELECT 
  DATE(ingestion_timestamp) as report_date,
  COUNT(DISTINCT asset_id) as total_assets_tracked,
  ROUND(SUM(marketCapUsd) / 1000000000, 2) as total_market_cap_billions,
  ROUND(SUM(volume_usd_24h) / 1000000000, 2) as total_volume_billions
FROM silver_assets
WHERE ingestion_timestamp = (SELECT MAX(ingestion_timestamp) FROM silver_assets)
GROUP BY DATE(ingestion_timestamp);

-- COMMAND ----------

-- QUESTION 4: Trend Analysis (Gainers vs Losers)
-- Explanation: Show the top 5 gainers and top 5 losers in the last 24h.

(SELECT 
  'Top Gainer' as category,
  symbol, 
  percent_change_24h 
 FROM silver_assets 
 WHERE ingestion_timestamp = (SELECT MAX(ingestion_timestamp) FROM silver_assets)
 ORDER BY percent_change_24h DESC LIMIT 5)
UNION ALL
(SELECT 
  'Top Loser' as category,
  symbol, 
  percent_change_24h 
 FROM silver_assets 
 WHERE ingestion_timestamp = (SELECT MAX(ingestion_timestamp) FROM silver_assets)
 ORDER BY percent_change_24h ASC LIMIT 5)
ORDER BY percent_change_24h DESC;

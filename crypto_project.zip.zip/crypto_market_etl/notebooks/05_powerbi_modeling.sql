-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 5️⃣ Reporting Layer: Power BI Optimization
-- MAGIC **Goal**: Create a Star Schema (Fact/Dim) for efficient Power BI reporting.

-- COMMAND ----------

-- 1. Dim_Asset
-- Source: Silver Assets (Unique List)
-- Enriched with: Platinum Clusters

CREATE OR REPLACE VIEW dim_asset AS
SELECT DISTINCT
    s.asset_id,
    s.symbol,
    s.name,
    COALESCE(p.cluster_id, -1) as risk_cluster_id,
    CASE 
        WHEN p.cluster_id = 0 THEN 'Stable / Low Volatility'
        WHEN p.cluster_id = 1 THEN 'Speculative / High Risk'
        WHEN p.cluster_id = 2 THEN 'Volatile / Medium Risk'
        ELSE 'Unknown'
    END as risk_profile_desc
FROM silver_assets s
LEFT JOIN platinum_asset_clusters p ON s.asset_id = p.asset_id;

-- COMMAND ----------

-- 2. Fact_Market_History
-- Source: Silver Assets (TimeSeries)

CREATE OR REPLACE VIEW fact_market_history AS
SELECT 
    asset_id,
    ingestion_timestamp,
    DATE(ingestion_timestamp) as report_date,
    price_usd,
    volume_usd_24h,
    marketCapUsd,
    percent_change_24h
FROM silver_assets;

-- COMMAND ----------

-- 3. Fact_Anomalies
-- Source: Platinum Anomalies

CREATE OR REPLACE VIEW fact_anomalies AS
SELECT 
    asset_id,
    ingestion_timestamp,
    price_usd,
    z_score,
    CASE 
        WHEN z_score > 3 THEN 'Surge'
        WHEN z_score < -3 THEN 'Crash'
    END as anomaly_type
FROM platinum_price_anomalies;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Power BI Connection Instructions
-- MAGIC 1. Open Power BI Desktop.
-- MAGIC 2. Get Data -> Azure Databricks.
-- MAGIC 3. Select **Import** Mode.
-- MAGIC 4. Load `dim_asset`, `fact_market_history`, and `fact_anomalies`.
-- MAGIC 5. Go to **Model View**.
-- MAGIC 6. Create Relationships:
-- MAGIC    - `dim_asset.asset_id` (1) -> `fact_market_history.asset_id` (*)
-- MAGIC    - `dim_asset.asset_id` (1) -> `fact_anomalies.asset_id` (*)

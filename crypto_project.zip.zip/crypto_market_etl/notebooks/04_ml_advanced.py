# Databricks notebook source
# MAGIC %md
# MAGIC # 4️⃣ Platinum Layer: Machine Learning & Advanced Stats
# MAGIC **Goal**: Use Spark MLlib to cluster assets and Statistical Analysis for Anomaly Detection.

# COMMAND ----------

import sys
import os

project_root = os.path.abspath(os.path.join(os.getcwd(), ".."))
if project_root not in sys.path:
    sys.path.append(project_root)

# COMMAND ----------

from src.analyze.aggregations import GoldAnalyzer
from src.ml.clustering import CryptoClusterModel

# Configuration
GOLD_STATS_NAME = "gold_asset_stats"
GOLD_VOLATILITY_NAME = "gold_volatility"
PLATINUM_CLUSTERS_PATH = "/FileStore/tables/crypto_project/platinum_clusters"
PLATINUM_CLUSTERS_NAME = "platinum_asset_clusters"
PLATINUM_ANOMALIES_PATH = "/FileStore/tables/crypto_project/platinum_anomalies"
PLATINUM_ANOMALIES_NAME = "platinum_price_anomalies"

# COMMAND ----------

# Load Gold Data
df_stats = spark.read.table(GOLD_STATS_NAME)
df_volatility = spark.read.table(GOLD_VOLATILITY_NAME)
df_silver = spark.read.table("silver_assets") # Needed for Anomalies

# COMMAND ----------

# 1. Machine Learning: K-Means Clustering
print("Running K-Means Clustering...")
cluster_model = CryptoClusterModel(spark)
df_clusters = cluster_model.train_and_predict(df_stats, df_volatility)

# Write to Platinum Layer
(df_clusters.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .option("path", PLATINUM_CLUSTERS_PATH)
    .saveAsTable(PLATINUM_CLUSTERS_NAME))

print(f"Clusters saved to {PLATINUM_CLUSTERS_NAME}")
display(df_clusters)

# COMMAND ----------

# 2. Advanced Stats: Anomaly Detection
print("Detecting Price Anomalies (Z-Score > 3)...")
analyzer = GoldAnalyzer(spark)
df_anomalies = analyzer.calculate_anomalies(df_silver, threshold=3.0)

# Write to Platinum Layer
(df_anomalies.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .option("path", PLATINUM_ANOMALIES_PATH)
    .saveAsTable(PLATINUM_ANOMALIES_NAME))

print(f"Anomalies saved to {PLATINUM_ANOMALIES_NAME}")
display(df_anomalies)

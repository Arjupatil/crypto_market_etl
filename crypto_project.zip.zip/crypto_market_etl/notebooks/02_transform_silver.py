# Databricks notebook source
# MAGIC %md
# MAGIC # 2️⃣ Silver Layer: Transformation (Enterprise)
# MAGIC **Goal**: Clean and standardize data using `BronzeToSilverTransformer`.

# COMMAND ----------

import sys
import os

# Robust path handling for Databricks Repos
notebook_path = os.getcwd()
project_root = os.path.abspath(os.path.join(notebook_path, ".."))

if project_root not in sys.path:
    sys.path.append(project_root)

if "/Workspace/Repos" in notebook_path:
     repo_root = notebook_path.split("notebooks")[0]
     if repo_root not in sys.path:
         sys.path.append(repo_root)

# COMMAND ----------

from src.transform.bronze_to_silver import BronzeToSilverTransformer

# Configuration
BRONZE_TABLE_NAME = "bronze_assets_raw"
SILVER_TABLE_PATH = "/FileStore/tables/crypto_project/silver_assets"
SILVER_TABLE_NAME = "silver_assets"

# COMMAND ----------

# 1. Read Bronze
df_bronze = spark.read.table(BRONZE_TABLE_NAME)

# 2. Initialize Transformer
transformer = BronzeToSilverTransformer(spark)

# 3. Transform
df_silver = transformer.transform(df_bronze)

# 4. Write to Silver
(df_silver.write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .option("path", SILVER_TABLE_PATH)
    .saveAsTable(SILVER_TABLE_NAME))

print(f"Transformed data saved to {SILVER_TABLE_NAME}")

# Databricks notebook source
# MAGIC %md
# MAGIC # 3️⃣ Gold Layer: Analytics (Enterprise)
# MAGIC **Goal**: Aggregate metrics using `GoldAnalyzer`.

# COMMAND ----------

import sys
import os

# Robust path handling for Databricks Repos
notebook_path = os.getcwd()
project_root = os.path.abspath(os.path.join(notebook_path, ".."))

if project_root not in sys.path:
    sys.path.append(project_root)

if "/Workspace/Repos" in notebook_path:
     repo_root = notebook_path.split("notebooks")[0]
     if repo_root not in sys.path:
         sys.path.append(repo_root)

# COMMAND ----------

from src.analyze.aggregations import GoldAnalyzer

# Configuration
SILVER_TABLE_NAME = "silver_assets"
GOLD_STATS_PATH = "/FileStore/tables/crypto_project/gold_asset_stats"
GOLD_STATS_NAME = "gold_asset_stats"
GOLD_VOLATILITY_PATH = "/FileStore/tables/crypto_project/gold_volatility"
GOLD_VOLATILITY_NAME = "gold_volatility"

# Load Silver
df_silver = spark.read.table(SILVER_TABLE_NAME)

# Initialize Analyzer
analyzer = GoldAnalyzer(spark)

# COMMAND ----------

# 1. Market Dominance
df_dominance = analyzer.calculate_market_dominance(df_silver)

(df_dominance.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .option("path", GOLD_STATS_PATH)
    .saveAsTable(GOLD_STATS_NAME))

print(f"Created {GOLD_STATS_NAME}")

# COMMAND ----------

# 2. Volatility
df_volatility = analyzer.calculate_volatility(df_silver)

(df_volatility.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .option("path", GOLD_VOLATILITY_PATH)
    .saveAsTable(GOLD_VOLATILITY_NAME))

print(f"Created {GOLD_VOLATILITY_NAME}")

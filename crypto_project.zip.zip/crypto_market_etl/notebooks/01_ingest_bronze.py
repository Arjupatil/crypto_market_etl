# Databricks notebook source
# MAGIC %md
# MAGIC # 1️⃣ Bronze Layer: Data Ingestion (Enterprise)
# MAGIC **Goal**: Ingest real-time crypto data using modular `CoinCapConnector`.

# COMMAND ----------

import sys
import os

# Add project root to path so we can import src
# Robust way to find project root in local or Databricks Repos
notebook_path = os.getcwd()
project_root = os.path.abspath(os.path.join(notebook_path, ".."))

if project_root not in sys.path:
    sys.path.append(project_root)

# For Databricks Repos specific handling if needed (often redundant but safe)
# This handles cases where CWD might be different in some runtime versions
if "/Workspace/Repos" in notebook_path:
     repo_root = notebook_path.split("notebooks")[0]
     if repo_root not in sys.path:
         sys.path.append(repo_root)

# COMMAND ----------

from src.extract.coincap_api import CoinCapConnector
from pyspark.sql.types import StructType, StructField, StringType, TimestampType

# Configuration
BRONZE_TABLE_PATH = "/FileStore/tables/crypto_project/bronze_assets_raw"
BRONZE_TABLE_NAME = "bronze_assets_raw"

# COMMAND ----------

# 1. Initialize Connector
connector = CoinCapConnector()

# 2. Fetch Data
print("Fetching real-time data...")
raw_data = connector.fetch_assets()

if not raw_data:
    dbutils.notebook.exit("Failed to fetch data.")

print(f"Fetched {len(raw_data)} assets.")

# 3. Prepare for Bronze
prepared_data = connector.prepare_for_bronze(raw_data)

# 4. Create DataFrame
schema = StructType([
    StructField("asset_id_raw", StringType(), True),
    StructField("payload", StringType(), True),
    StructField("source", StringType(), True),
    StructField("ingestion_timestamp", TimestampType(), True)
])

df_raw = spark.createDataFrame(prepared_data, schema=schema)

# 5. Write to Delta
(df_raw.write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .option("path", BRONZE_TABLE_PATH)
    .saveAsTable(BRONZE_TABLE_NAME))

print(f"Data successfully appended to {BRONZE_TABLE_NAME}")

import os
import sys
import shutil
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, TimestampType

# Ensure src is in path
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from src.extract.coincap_api import CoinCapConnector
from src.transform.bronze_to_silver import BronzeToSilverTransformer
from src.analyze.aggregations import GoldAnalyzer
from src.ml.clustering import CryptoClusterModel

def run_pipeline():
    print("🚀 Starting Local Crypto ETL Pipeline...")

    # 0. Initialize Spark
    spark = SparkSession.builder \
        .appName("CryptoETL_Local") \
        .master("local[1]") \
        .config("spark.sql.warehouse.dir", "spark-warehouse") \
        .getOrCreate()
    
    # Clean up previous runs
    if os.path.exists("spark-warehouse"):
        shutil.rmtree("spark-warehouse", ignore_errors=True)

    # --- Step 1: Ingest (Bronze) ---
    print("\n1️⃣ Processing Bronze Layer...")
    connector = CoinCapConnector()
    raw_data = connector.fetch_assets()
    
    if not raw_data:
        print("❌ Failed to fetch data. Exiting.")
        return

    prepared_data = connector.prepare_for_bronze(raw_data)
    
    schema = StructType([
        StructField("asset_id_raw", StringType(), True),
        StructField("payload", StringType(), True),
        StructField("source", StringType(), True),
        StructField("ingestion_timestamp", TimestampType(), True)
    ])
    
    df_bronze = spark.createDataFrame(prepared_data, schema=schema)
    df_bronze.createOrReplaceTempView("bronze_assets_raw")
    print(f"✅ Ingested {df_bronze.count()} records to Bronze.")

    # --- Step 2: Transform (Silver) ---
    print("\n2️⃣ Processing Silver Layer...")
    transformer = BronzeToSilverTransformer(spark)
    df_silver = transformer.transform(df_bronze)
    df_silver.createOrReplaceTempView("silver_assets")
    print(f"✅ Transformed {df_silver.count()} records to Silver.")
    df_silver.show(5)

    # --- Step 3: Analytics (Gold) ---
    print("\n3️⃣ Processing Gold Layer...")
    analyzer = GoldAnalyzer(spark)
    
    # Dominance
    df_dominance = analyzer.calculate_market_dominance(df_silver)
    df_dominance.createOrReplaceTempView("gold_asset_stats")
    print("✅ Calculated Market Dominance.")
    
    # Volatility
    df_volatility = analyzer.calculate_volatility(df_silver)
    df_volatility.createOrReplaceTempView("gold_volatility")
    print("✅ Calculated Volatility.")

    # Anomalies (Stats)
    df_anomalies = analyzer.calculate_anomalies(df_silver)
    print(f"✅ Detected {df_anomalies.count()} Price Anomalies.")
    df_anomalies.show()

    # --- Step 4: ML (Platinum) ---
    print("\n4️⃣ Processing Platinum Layer (ML)...")
    cluster_model = CryptoClusterModel(spark)
    df_clusters = cluster_model.train_and_predict(df_dominance, df_volatility)
    print("✅ Generated Clusters.")
    df_clusters.show(10)

    print("\n🎉 Pipeline Finished Successfully!")
    spark.stop()

if __name__ == "__main__":
    run_pipeline()

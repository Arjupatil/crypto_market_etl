# Databricks notebook source
# MAGIC %md
# MAGIC # 3️⃣ Gold Layer: Analytics & Aggregates
# MAGIC **Goal**: Create business-ready tables for reporting and dashboards.
# MAGIC 
# MAGIC **Key Metrics**:
# MAGIC - **Market Dominance**: Percent share of total market cap.
# MAGIC - **Volatility**: Standard deviation of price (risk metric).
# MAGIC - **Price Performance**: Gainers/Losers.

# COMMAND ----------

from pyspark.sql.functions import col, sum, avg, stddev, desc, max, min, current_timestamp, window, expr
from pyspark.sql.window import Window

# Configuration
SILVER_TABLE_NAME = "silver_assets"
GOLD_STATS_PATH = "/FileStore/tables/crypto_project/gold_asset_stats"
GOLD_STATS_NAME = "gold_asset_stats"
GOLD_VOLATILITY_PATH = "/FileStore/tables/crypto_project/gold_volatility"
GOLD_VOLATILITY_NAME = "gold_volatility"

# Load Silver Data
df_silver = spark.read.table(SILVER_TABLE_NAME)

# COMMAND ----------

# Metric 1: Market Dominance Calculation
# Calculate total market cap per distinct timestamp (assuming we use the latest batch ingestion)
# For this example, we'll take the LATEST snapshot available in Silver.

latest_timestamp = df_silver.select(max("ingestion_timestamp")).collect()[0][0]
df_latest = df_silver.filter(col("ingestion_timestamp") == latest_timestamp)

total_market_cap = df_latest.select(sum("marketCapUsd")).collect()[0][0]

df_dominance = df_latest.withColumn("market_dominance_pct", (col("marketCapUsd") / total_market_cap) * 100) \
                        .select("asset_id", "symbol", "market_dominance_pct", "marketCapUsd", "ingestion_timestamp")

# COMMAND ----------

# Metric 2: Price Volatility (Standard Deviation)
# We need historical data for this. Let's look at the last 24 hours of data.
# Note: This requires enough history in Silver.

df_history_24h = df_silver.filter(col("ingestion_timestamp") >= expr("now() - INTERVAL 24 HOURS"))

volatility_window = Window.partitionBy("asset_id")

df_volatility = df_history_24h.groupBy("asset_id", "symbol").agg(
    stddev("price_usd").alias("price_std_dev_24h"),
    avg("price_usd").alias("avg_price_24h"),
    max("price_usd").alias("max_price_24h"),
    min("price_usd").alias("min_price_24h"),
    avg("volume_usd_24h").alias("avg_volume_24h")
).withColumn("volatility_index", col("price_std_dev_24h") / col("avg_price_24h")) # Coefficient of Variation

# COMMAND ----------

# 3. Create Gold Tables

# Table A: Asset Statistics (Latest Snapshot + Dominance)
(df_dominance.write
    .format("delta")
    .mode("overwrite") # Overwrite for snapshot tables, or append if tracking daily snapshots
    .option("overwriteSchema", "true")
    .option("path", GOLD_STATS_PATH)
    .saveAsTable(GOLD_STATS_NAME))

print(f"Created {GOLD_STATS_NAME}")

# Table B: Key Volatility Metrics
(df_volatility.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .option("path", GOLD_VOLATILITY_PATH)
    .saveAsTable(GOLD_VOLATILITY_NAME))

print(f"Created {GOLD_VOLATILITY_NAME}")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Visual Check: Top 5 Most Volatile Assets (Relative to Price)
# MAGIC SELECT symbol, volatility_index, price_std_dev_24h, avg_price_24h 
# MAGIC FROM gold_volatility 
# MAGIC ORDER BY volatility_index DESC 
# MAGIC LIMIT 5

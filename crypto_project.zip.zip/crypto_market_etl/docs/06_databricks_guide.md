# 🚀 Running Crypto ETL on Databricks

This guide will walk you through running your project on Databricks Community Edition (free) or a paid workspace. We will use **Databricks Repos** which allows you to sync your code directly from Git.

## Prerequisites
1.  **Databricks Account**: Sign up for [Databricks Community Edition](https://community.cloud.databricks.com/login.html) if you don't have one.
2.  **Git Repository**: Your code must be pushed to a Git provider (GitHub, GitLab, Bitbucket).

---

## Step 1: Create a Cluster
You need a cluster to run your code.

1.  Log in to your Databricks workspace.
2.  Click **Compute** in the left sidebar.
3.  Click **Create with Personal Compute** (or "Create Compute").
4.  **Name**: `CryptoCluster`.
5.  **Databricks Runtime Version**: Select **11.3 LTS ML** or higher (LTS is recommended for stability).
6.  **Instance Type** (if asked): Select a small node type (e.g., Standard_DS3_v2). For Community Edition, this is pre-selected.
7.  Click **Create Compute**. Wait for the green circle (running state).

---

## Step 2: Set Up Databricks Repos
This brings your code into Databricks.

1.  Click **Workspace** > **Repos** in the left sidebar.
2.  Click **Add Repo**.
3.  **Git URL**: Paste the URL of your GitHub repository (e.g., `https://github.com/your-username/crypto_market_etl.git`).
4.  **Git Provider**: Select GitHub.
5.  Click **Create Repo**.

*Now you should see your project files inside Databricks!*

---

## Step 3: Install Dependencies
We need to make sure the cluster has the required libraries. Since we are using standard PySpark, most are included, but let's be safe.

1.  Open your Repo folder in Databricks.
2.  Create a new notebook named `00_init_setup` in the root or `notebooks/` folder.
3.  Add the following command and run it:
    ```python
    %pip install -r ../requirements.txt
    ```
    *(Note: adjust the path `../requirements.txt` depending on where you create this notebook. If you are in `notebooks/` folder, `../` is correct.)*

---

## Step 4: Run the Pipeline
Now we run the notebooks in order.

### 1. Ingest Data (Bronze)
1.  Navigate to `notebooks/01_ingest_bronze`.
2.  Check the "Connect" button at the top right to ensure it's connected to your `CryptoCluster`.
3.  Click **Run All**.
4.  Wait for the specific output: `Data successfully appended to bronze_assets_raw`.

### 2. Transform Data (Silver)
1.  Navigate to `notebooks/02_transform_silver`.
2.  Click **Run All**.
3.  Verify output: `Transformed data saved to silver_assets`.

### 3. Analyze Data (Gold)
1.  Navigate to `notebooks/03_analytics_gold`.
2.  Click **Run All**.
3.  Verify output: `Created gold_asset_stats` and `Created gold_volatility`.

---

## Step 5: Verify Data with SQL
You can query your tables directly.

1.  Click **SQL Editor** or create a new Notebook.
2.  Run the following SQL queries:

```sql
-- Check Bronze Data
SELECT * FROM bronze_assets_raw LIMIT 10;

-- Check Silver Data
SELECT * FROM silver_assets LIMIT 10;

-- Check Market Dominance (Gold)
SELECT * FROM gold_asset_stats ORDER BY market_dominance_pct DESC;
```

---

## Troubleshooting
- **Module not found error**: If you see `ModuleNotFoundError: No module named 'src'`, it means the system path isn't set correctly. The updated notebooks in this repo handle this, ensuring `src` is discoverable.
- **Cluster connection**: If cells verify "Detached", attach to your cluster using the dropdown at the top right.

# 6️⃣ Power BI Dashboard Design

## Overview
The Power BI dashboard connects to the **Gold Layer** (Delta Tables) to visualize market trends, volatility, and key metrics.

## Data Connection
- **Connector**: Azure Databricks Connector (DirectQuery or Import Mode).
- **Cluster**: Server Hostname & HTTP Path (Found in Compute -> Advanced Options -> JDBC/ODBC).
- **Tables**: `gold_asset_stats`, `gold_volatility`.

## Data Model (Star Schema)
- **Fact Table**: `gold_volatility` (Historical metrics).
- **Dim Table**: `gold_asset_stats` (Current snapshot metadata like Rank, Name).
- **Relationship**: `One-to-Many` on `symbol` or `asset_id`.

## Visualization Plan

### Page 1: Market Overview (Executive View)
1. **KPI Cards (Top Row)**:
   - Total Market Cap ($)
   - 24h Total Volume ($)
   - BTC Dominance (%)
2. **Scatter Plot (Risk vs Reward)**:
   - **X-Axis**: Volatility Index (`volatility_index`)
   - **Y-Axis**: 24h Price Change % (`percent_change_24h`)
   - **Size**: Market Cap
   - **Tooltip**: Symbol, Price
3. **Bar Chart**: Top 10 Gainers (Green) vs Top 10 Losers (Red).

### Page 2: Coin Deep Dive (Drill-through)
1. **Line Chart**: Price History (Last 24h)
   - *Requires historical table if not pre-aggregated.*
2. **Gauge Chart**: Volume / Market Cap Ratio.
   - 0-0.1 (Low Activity)
   - 0.1-0.5 (Healthy)
   - 0.5+ (High/Speculative)

## Refresh Strategy
- **Power BI Service**: Scheduled Refresh.
- **Frequency**: Every 30 minutes (aligned effectively with 10-min ETL runs).

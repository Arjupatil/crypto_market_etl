# 5️⃣ Automation: Scheduling Databricks Jobs

## Overview
To simulate a real-time/near real-time pipeline, we will use **Databricks Jobs** to orchestrate the execution of our notebooks.

## Job Configuration

### 1. Create a New Job
- **Job Name**: `Crypto_Market_ETL_Pipeline`
- **Schedule**: `*/10 * * * *` (Every 10 minutes) OR use the UI dropdown to select "Every 10 minutes".

### 2. Task Definitions (Directed Acyclic Graph - DAG)

The job will consist of 3 sequential tasks:

#### Task 1: Ingestion
- **Task Name**: `Ingest_Bronze`
- **Type**: Notebook
- **Path**: `/Repos/Production/crypto_market_etl/01_ingest_bronze`
- **Cluster**: Use `Job Cluster` (Cheaper) or `All-Purpose Cluster` (Faster startup if already running).
- **Retries**: 3 (Policy: Linear wait 1 min)

#### Task 2: Transformation
- **Task Name**: `Transform_Silver`
- **Depends On**: `Ingest_Bronze`
- **Type**: Notebook
- **Path**: `/Repos/Production/crypto_market_etl/02_transform_silver`

#### Task 3: Analytics
- **Task Name**: `Build_Gold_Metrics`
- **Depends On**: `Transform_Silver`
- **Type**: Notebook
- **Path**: `/Repos/Production/crypto_market_etl/03_analytics_gold`

## Monitoring & Alerts
- **Email Notifications**:
  - **On Start**: None
  - **On Success**: None (to reduce noise)
  - **On Failure**: `data-engineering-team@company.com`

## Why This Architecture?
- **Decoupling**: Each layer handles a specific responsibility.
- **Dependency Management**: Silver waits for Bronze success; Gold waits for Silver success.
- **Observability**: Databricks Job UI provides a Gantt chart of execution times to identify bottlenecks.

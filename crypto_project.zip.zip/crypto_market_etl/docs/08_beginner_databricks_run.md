# 🔰 Databricks for Absolute Beginners (Step-by-Step)

This guide takes you through exactly what to click, step by step, assuming you have never used Databricks before.

## 1. Get Your Files Ready (On Your Computer)
First, we need to pack up your code so we can upload it.

1.  Open your file explorer on your computer.
2.  Go to your project folder: `d:\projects\crypto_market_etl`
    *(Or wherever you saved the project)*
3.  **Right-click** on the `crypto_market_etl` folder.
4.  Select **Send to** > **Compressed (zipped) folder**.
5.  Rename the new zip file to `crypto_project.zip`.
    *(Remember where this file is!)*

---

## 2. Log In to Databricks
1.  Go to this link: [Databricks Community Edition Login](https://community.cloud.databricks.com/login.html)
2.  Enter your email and password.
3.  Click **Sign In**.

---

## 3. Create a Computer (Cluster)
We need a computer in the cloud to run your code. This is called a "Cluster".

1.  Look at the **Left Sidebar** (dark grey bar on the left).
2.  Click on **Compute**.
3.  Click the blue button that says **Create Compute** (or "Create with Personal Compute").
4.  **Name**: Type `MyFirstCluster`.
5.  **Databricks Runtime Version**: Click the dropdown and select **11.3 LTS ML** (or any 11.3+ version).
6.  Click the blue **Create Compute** button at the bottom.
7.  **WAIT**. It will take 3-5 minutes. Wait until the circle next to the name turns **Green**.

---

## 4. Upload Your Code
Now we put your code into Databricks.

1.  Click **Workspace** in the Left Sidebar.
2.  Click **Users** > then click **Your Email Address**.
3.  **Right-click** in the empty white space in the middle of the screen.
4.  Hover over **Import**, then click **Import**.
5.  A box will pop up. 
    - Click **browse** or drag your `crypto_project.zip` file into the box.
    - Click **Import** at the bottom.
6.  You should now see a folder named `crypto_project`. **Click securely on it to open it.**

---

## 5. Install Required Libraries
We need to install some tools for your code to work.

1.  Inside your `crypto_project` folder, double-click the `notebooks` folder to open it.
2.  **Right-click** in the empty space -> **Create** -> **Notebook**.
3.  Name it: `Install_Libs`.
4.  In the first empty box (cell), copy and paste this exactly:
    ```python
    %pip install -r ../requirements.txt
    ```
    *(If that fails, just use: `%pip install requests pyspark delta-spark pandas`)*
5.  Press **Shift + Enter** on your keyboard to run it. 
    - Or click the small **Play icon (▶)** at the top right of the cell -> **Run Cell**.
6.  Wait until it says "Command took X seconds" at the bottom of the cell.

---

## 6. Run the Project (The Fun Part!)
Now run the notebooks in order.

### Step 6.1: Get Data (Bronze)
1.  Go back to the `notebooks` folder.
2.  Click on **01_ingest_bronze**.
3.  Look at the top center. It might say "Detached". Click the dropdown and select `MyFirstCluster`.
4.  Click **Run All** at the top of the screen.
5.  Scroll down to the last cell.
    - **Success Message**: You should see: `Data successfully appended to bronze_assets_raw`.

### Step 6.2: Clean Data (Silver)
1.  Go back to the `notebooks` folder.
2.  Click on **02_transform_silver**.
3.  Ensure it is attached to `MyFirstCluster`.
4.  Click **Run All**.
5.  **Success Message**: `Transformed data saved to silver_assets`.

### Step 6.3: Analyze Data (Gold)
1.  Go back to `notebooks`.
2.  Click on **03_analytics_gold**.
3.  Click **Run All**.
4.  **Success Message**: `Created gold_asset_stats`.

---

## 7. See Your Results
You can query the tables you just created.

1.  Click **New** (top left) -> **Notebook**.
2.  Copy and paste this SQL command:
    ```sql
    %sql
    SELECT * FROM gold_asset_stats ORDER BY market_dominance_pct DESC
    ```
3.  Press **Shift + Enter**.
4.  You will see a table with Bitcoin, Ethereum, etc., and their dominance percentage!

**Congratulations! You just ran an Enterprise Data Engineering Pipeline!** 🚀

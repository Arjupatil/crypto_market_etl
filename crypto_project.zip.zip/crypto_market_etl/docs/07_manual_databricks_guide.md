# 📦 Manual Run on Databricks (No Git)

This guide shows you how to run the project by manually uploading files to Databricks.

## Prerequisites
1.  **Databricks Account**: [Community Edition (Free)](https://community.cloud.databricks.com/login.html) or Corporate.
2.  **Local Project Files**: The files on your computer.

---

## Step 1: Prepare Your Files
1.  Go to your project folder:
    `c:\Users\Arju Patil\.gemini\antigravity\scratch\crypto_market_etl`
2.  **Create a Zip file** of the entire `crypto_market_etl` folder.
    - Right-click the folder -> **Send to** -> **Compressed (zipped) folder**.
    - Rename it to `crypto_project.zip`.

---

## Step 2: Create a Cluster
(Skip this if you already have a running cluster)
1.  Log in to Databricks.
2.  Click **Compute** (left sidebar).
3.  Click **Create Compute**.
4.  Name: `CryptoCluster`.
5.  Select Runtime: **11.3 LTS ML** (or typically any 11.3+ version).
6.  Click **Create Compute** and wait for it to start.

---

## Step 3: Import Code to Databricks
1.  Click **Workspace** (left sidebar).
2.  Click **Users** -> Your Username.
3.  Right-click in the empty white space -> **Import**.
4.  **Import from:** Select **File**.
5.  Drag and drop your `crypto_project.zip` file here.
6.  Click **Import**.
    - *Databricks will unzip the folder automatically.*
    - You should now see a folder named `crypto_project` (or similar) containing `notebooks`, `src`, etc.

---

## Step 4: Install Libraries
1.  Click on the newly imported folder to open it.
2.  Find `requirements.txt`.
    - *Note: If you can't click it to run, we'll install manually.*
3.  Go into `notebooks` folder.
4.  Right-click -> **Create** -> **Notebook**. Name it `Install_Libs`.
5.  In the first cell, paste this and click **Run** (Play icon):
    ```python
    %pip install requests pyspark delta-spark pandas
    ```
    *(These are the contents of your requirements.txt)*

---

## Step 5: Run the Project
Now run the notebooks in order.

### 1. Ingest (Bronze)
1.  Open `notebooks/01_ingest_bronze`.
2.  Attach your cluster (top right dropdown).
3.  Click **Run All**.

### 2. Transform (Silver)
1.  Open `notebooks/02_transform_silver`.
2.  Click **Run All**.

### 3. Analytics (Gold)
1.  Open `notebooks/03_analytics_gold`.
2.  Click **Run All**.

---

## Troubleshooting
- **"No module named src"**:
    - This happens if the folder structure is messy after unzip.
    - Make sure your folder structure in Databricks looks like this:
      ```
      /Workspace/Users/.../crypto_project/
         ├── src/
         ├── notebooks/
      ```
    - If `src` is inside another subfolder, move the notebooks up or adjust the code.

# 🚀 How to Run on Databricks

This guide explains how to deploy and run the Crypto ETL pipeline on Databricks (Community Edition or Professional).

## 1. Prerequisites
- **Databricks Account**: [Sign up for Community Edition](https://community.cloud.databricks.com/login.html) (Free) if you don't have one.
- **Cluster**: Create a Compute Cluster.
  - Runtime: **12.2 LTS** or newer (Standard or ML).
  - Node Type: Standard (e.g., 1 Driver, 0 Workers for Community Edition).

## 2. Importing the Project
1. **Download** the project files locally (`01_ingest_bronze.py`, etc.).
2. Go to your Databricks Workspace (e.g., `/Users/your@email.com/`).
3. Right-click in the workspace area and select **Import**.
4. In the Import dialog:
   - Select **File** or **Browse**.
   - Upload the `.py` files (`01_...`, `02_...`, `03_...`) and the SQL file (`04_...`).
   - Databricks will automatically convert them into **Notebooks** because they involve the `# Databricks notebook source` header.

## 3. Execution Order (Manual)
Run the notebooks in the following order to populate your Data Lakehouse.

### Step 1: Ingest Data (Bronze)
- Open `01_ingest_bronze` notebook.
- **Run All**.
- This will fetch data from CoinCap API and save it to `bronze_assets_raw` table.
- *Note*: If you see an error about `requests` module, add a cell at the top with `%pip install requests` and run it.

### Step 2: Transform Data (Silver)
- Open `02_transform_silver` notebook.
- **Run All**.
- This reads from Bronze, cleans the data, and saves to `silver_assets` table.
- Verify the output in the bottom cell.

### Step 3: Analytics (Gold)
- Open `03_analytics_gold` notebook.
- **Run All**.
- This aggregates Silver data into `gold_asset_stats` and `gold_volatility` tables.

### Step 4: Business Insights (SQL)
- Open `04_business_questions` notebook.
- **Run All**.
- This runs SQL queries against your Gold data to answer business questions.

## 4. Automation (Optional)
To simulate a real-world pipeline:
1. Go to **Workflows** (Jobs).
2. Create a **New Job**.
3. Add **Task 1**:
   - Type: Notebook
   - Path: Select `01_ingest_bronze`
4. Add **Task 2**:
   - Type: Notebook
   - Path: Select `02_transform_silver`
   - Depends On: Task 1
5. Add **Task 3**:
   - Type: Notebook
   - Path: Select `03_analytics_gold`
   - Depends On: Task 2
6. **Run Job**.

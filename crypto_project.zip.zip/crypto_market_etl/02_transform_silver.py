# Databricks notebook source
# MAGIC %md
# MAGIC # 2️⃣ Silver Layer: Transformation & Cleaning
# MAGIC **Goal**: Parse raw JSON from Bronze, enforce types, clean data, and deduplicate.
# MAGIC 
# MAGIC **Transformations**:
# MAGIC - JSON Parsing -> Structured Columns.
# MAGIC - Type Casting (Strings -> Decimal/Double).
# MAGIC - Deduplication (Ensure unique checks).
# MAGIC - Handle Nulls.

# COMMAND ----------

from pyspark.sql.functions import from_json, col, current_timestamp, to_timestamp, regexp_replace
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, LongType

# Configuration
BRONZE_TABLE_NAME = "bronze_assets_raw"
SILVER_TABLE_PATH = "/FileStore/tables/crypto_project/silver_assets"
SILVER_TABLE_NAME = "silver_assets"

# COMMAND ----------

# 1. Read Bronze Data
# In a real streaming job, we would use readStream. For batch, we read the table.
df_bronze = spark.read.table(BRONZE_TABLE_NAME)

# COMMAND ----------

# 2. Define Schema for JSON API
# Based on CoinCap asset object
api_schema = StructType([
    StructField("id", StringType(), True),
    StructField("rank", StringType(), True), # API returns numeric strings
    StructField("symbol", StringType(), True),
    StructField("name", StringType(), True),
    StructField("supply", StringType(), True),
    StructField("maxSupply", StringType(), True),
    StructField("marketCapUsd", StringType(), True),
    StructField("volumeUsd24Hr", StringType(), True),
    StructField("priceUsd", StringType(), True),
    StructField("changePercent24Hr", StringType(), True),
    StructField("vwap24Hr", StringType(), True)
])

# COMMAND ----------

# 3. Parse and Flatten
df_parsed = df_bronze.withColumn("parsed_data", from_json(col("payload"), api_schema)) \
                     .select("ingestion_timestamp", "parsed_data.*")

# COMMAND ----------

# 4. Type Casting & Cleaning
# - Convert 'rank' to Integer
# - Convert numeric strings to Double
# - Handle missing MaxSupply (fill with 0 or -1, or leave null. We leave null for accuracy)
# - Clean names if necessary (trim)

df_cleaned = df_parsed.select(
    col("id").alias("asset_id"),
    col("rank").cast(IntegerType()).alias("rank"),
    col("symbol"),
    col("name"),
    col("supply").cast(DoubleType()),
    col("maxSupply").cast(DoubleType()),
    col("marketCapUsd").cast(DoubleType()),
    col("volumeUsd24Hr").cast(DoubleType()).alias("volume_usd_24h"),
    col("priceUsd").cast(DoubleType()).alias("price_usd"),
    col("changePercent24Hr").cast(DoubleType()).alias("percent_change_24h"),
    col("vwap24Hr").cast(DoubleType()).alias("vwap_24h"),
    col("ingestion_timestamp")
)

# 5. Quality Checks / Filters
# Remove rows where critical business keys are null
df_valid = df_cleaned.filter(col("asset_id").isNotNull() & col("price_usd").isNotNull())

# 6. Deduplication Strategy
# For a historical trend table, we WANT duplicates over time (TimeSeries).
# However, if we run the ingestion job multiple times within the same minute, we might want to dedupe.
# Here we will keep all records but add a 'processing_time' for audit.

df_silver = df_valid.withColumn("processed_time", current_timestamp())

# COMMAND ----------

# 7. Write to Silver (Delta)
# Upsert is useful if correcting data, but here we are building history.
# We will simple APPEND. 
# Partitioning by Date might be useful for large datasets.

(df_silver.write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .option("path", SILVER_TABLE_PATH)
    .saveAsTable(SILVER_TABLE_NAME))

print(f"Transformed data saved to {SILVER_TABLE_NAME}")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Sanity Check
# MAGIC SELECT asset_id, price_usd, ingestion_timestamp 
# MAGIC FROM silver_assets 
# MAGIC WHERE symbol = 'BTC' 
# MAGIC ORDER BY ingestion_timestamp DESC 
# MAGIC LIMIT 5

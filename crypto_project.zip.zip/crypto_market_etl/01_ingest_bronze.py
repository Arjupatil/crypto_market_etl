# Databricks notebook source
# MAGIC %md
# MAGIC # 1️⃣ Bronze Layer: Data Ingestion
# MAGIC **Goal**: Ingest real-time crypto data from CoinCap API and store raw JSON in Delta Lake.
# MAGIC 
# MAGIC **Key Features**:
# MAGIC - Exponential backoff for API rate limits.
# MAGIC - Raw schema preservation.
# MAGIC - Append-only logging.

# COMMAND ----------

import requests
import json
import time
from datetime import datetime
from pyspark.sql.types import StructType, StructField, StringType, TimestampType
from pyspark.sql.functions import current_timestamp, lit

# Configuration
API_URL = "https://api.coincap.io/v2/assets"
BRONZE_TABLE_PATH = "/FileStore/tables/crypto_project/bronze_assets_raw"
BRONZE_TABLE_NAME = "bronze_assets_raw"

# COMMAND ----------

def fetch_data_with_retry(url, retries=3, backoff_factor=2):
    """
    Fetches data from API with retry logic for robustness.
    """
    attempt = 0
    while attempt < retries:
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 429:
                print(f"Rate limit hit. Retrying in {backoff_factor ** attempt} seconds...")
                time.sleep(backoff_factor ** attempt)
            else:
                print(f"Failed with status {response.status_code}")
                return None
        except Exception as e:
            print(f"Error: {e}")
        
        attempt += 1
        time.sleep(1)
    return None

# COMMAND ----------

# 1. Fetch Data
print("Fetching real-time data from CoinCap...")
data_json = fetch_data_with_retry(API_URL)

if data_json:
    print(f"Successfully fetched {len(data_json['data'])} assets.")
else:
    dbutils.notebook.exit("Failed to fetch data.")

# COMMAND ----------

# 2. Create DataFrame
# We convert the entire response to a string to keep the 'Raw' nature of Bronze.
# In a strict raw implementation, we might store the whole blob. 
# Here we'll store individual asset blobs to make Silver easier, 
# but keep the schema 'raw' (just strings).

raw_data = []
timestamp_received = datetime.now()

# Parsing just enough to create rows, but keeping content raw
for asset in data_json['data']:
    raw_data.append({
        "asset_id_raw": asset.get('id'),
        "payload": json.dumps(asset),
        "source": "coincap_api",
        "ingestion_timestamp": timestamp_received
    })

# Define Schema for Bronze
schema = StructType([
    StructField("asset_id_raw", StringType(), True),
    StructField("payload", StringType(), True),
    StructField("source", StringType(), True),
    StructField("ingestion_timestamp", TimestampType(), True)
])

df_raw = spark.createDataFrame(raw_data, schema=schema)

# COMMAND ----------

# 3. Write to Delta Lake (Bronze)
# Merge Schema is enabled to assume schema evolution if API changes slightly (though we use raw string here)
(df_raw.write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .option("path", BRONZE_TABLE_PATH)
    .saveAsTable(BRONZE_TABLE_NAME))

print(f"Data successfully appended to {BRONZE_TABLE_NAME}")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify Data
# MAGIC SELECT * FROM bronze_assets_raw ORDER BY ingestion_timestamp DESC LIMIT 10

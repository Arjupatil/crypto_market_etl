from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.clustering import KMeans
from pyspark.sql.functions import col, when

class CryptoClusterModel:
    """
    K-Means Clustering model to classify crypto assets based on risk and dominance.
    """
    
    def __init__(self, spark):
        self.spark = spark
        self.k = 3
        self.features = ["volatility_index", "market_dominance_pct"]

    def train_and_predict(self, df_gold_stats, df_gold_volatility):
        """
        Joins Gold tables, prepares features, and runs K-Means.
        Returns DataFrame with 'risk_profile' column.
        """
        # 1. Join Gold Tables (Dominance + Volatility)
        df_joined = df_gold_stats.join(
            df_gold_volatility.select("asset_id", "volatility_index"), 
            on="asset_id", 
            how="inner"
        )

        # 2. Vectorize Features
        assembler = VectorAssembler(inputCols=self.features, outputCol="features_raw")
        df_vectorized = assembler.transform(df_joined)

        # 3. Scale Features (Important for K-Means)
        scaler = StandardScaler(inputCol="features_raw", outputCol="features", withStd=True, withMean=True)
        scaler_model = scaler.fit(df_vectorized)
        df_scaled = scaler_model.transform(df_vectorized)

        # 4. Train K-Means
        kmeans = KMeans(k=self.k, seed=42)
        model = kmeans.fit(df_scaled)
        
        # 5. Predict Clusters
        df_clustered = model.transform(df_scaled)

        # 6. Interpret Clusters (Naive heuristic for demo)
        # In a real scenario, we'd analyze cluster centers to name them dynamically.
        # Here we assume:
        # - High Volatility + Low Dominance = Speculative
        # - Low Volatility + High Dominance = Stable
        # - Mixed = Volatile
        
        # For simplicity, we just return the cluster ID. 
        # Advanced: Calculate distance to center to label High/Medium/Low risk.
        
        return df_clustered.select(
            "asset_id", 
            "symbol", 
            "market_dominance_pct", 
            "volatility_index", 
            "prediction"
        ).withColumnRenamed("prediction", "cluster_id")

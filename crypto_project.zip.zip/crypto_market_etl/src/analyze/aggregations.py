from pyspark.sql.functions import col, sum, avg, stddev, max, min, expr
from pyspark.sql.window import Window

class GoldAnalyzer:
    """
    Handles aggregation and analytics for the Gold layer.
    """
    
    def __init__(self, spark):
        self.spark = spark

    def calculate_market_dominance(self, df_silver):
        """
        Calculates market dominance percentage for each asset based on the latest snapshot.
        """
        # Get latest timestamp
        latest_timestamp = df_silver.select(max("ingestion_timestamp")).collect()[0][0]
        df_latest = df_silver.filter(col("ingestion_timestamp") == latest_timestamp)
        
        # Calculate Total Market Cap
        total_market_cap = df_latest.select(sum("marketCapUsd")).collect()[0][0]
        
        # Calculate Dominance
        df_dominance = df_latest.withColumn("market_dominance_pct", (col("marketCapUsd") / total_market_cap) * 100) \
                                .select("asset_id", "symbol", "market_dominance_pct", "marketCapUsd", "ingestion_timestamp")
                                
        return df_dominance

    def calculate_anomalies(self, df_silver, threshold=3.0):
        """
        Calculates price anomalies using Z-Score (Statistical Deviation).
        Rules:
        - Z-Score > 3: High Anomaly (Price Surge)
        - Z-Score < -3: Low Anomaly (Price Crash)
        """
        # 1. Calculate Mean and StdDev per asset
        stats = df_silver.groupBy("asset_id").agg(
            avg("price_usd").alias("mean_price"),
            stddev("price_usd").alias("std_dev_price")
        )

        # 2. Join back to original data
        df_stats = df_silver.join(stats, on="asset_id", how="inner")

        # 3. Calculate Z-Score
        # Formula: (Price - Mean) / StdDev
        df_zscore = df_stats.withColumn("z_score", (col("price_usd") - col("mean_price")) / col("std_dev_price"))

        # 4. Filter Anomalies
        df_anomalies = df_zscore.filter((col("z_score") > threshold) | (col("z_score") < -threshold)) \
            .select(
                "asset_id", "symbol", "price_usd", "mean_price", "z_score", "ingestion_timestamp"
            )

        return df_anomalies

    def calculate_volatility(self, df_silver):
        """
        Calculates volatility (standard deviation) over the last 24 hours.
        """
        # Filter last 24h
        df_history_24h = df_silver.filter(col("ingestion_timestamp") >= expr("now() - INTERVAL 24 HOURS"))
        
        # Aggregate stats
        df_volatility = df_history_24h.groupBy("asset_id", "symbol").agg(
            stddev("price_usd").alias("price_std_dev_24h"),
            avg("price_usd").alias("avg_price_24h"),
            max("price_usd").alias("max_price_24h"),
            min("price_usd").alias("min_price_24h"),
            avg("volume_usd_24h").alias("avg_volume_24h")
        ).withColumn("volatility_index", col("price_std_dev_24h") / col("avg_price_24h")) # Coefficient of Variation
        
        return df_volatility

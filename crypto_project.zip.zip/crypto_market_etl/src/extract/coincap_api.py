import requests
import time
import json
from datetime import datetime

class CoinCapConnector:
    """
    Handles connection and data retrieval from the CoinCap API.
    """
    def __init__(self, api_url="https://api.coincap.io/v2/assets", max_retries=3, backoff_factor=2):
        self.api_url = api_url
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor

    def fetch_assets(self):
        """
        Fetches asset data from the API with retry logic.
        Returns the raw data list (dict) or None if failed.
        """
        attempt = 0
        while attempt < self.max_retries:
            try:
                response = requests.get(self.api_url, timeout=10)
                if response.status_code == 200:
                    return response.json().get('data', [])
                elif response.status_code == 429:
                    wait_time = self.backoff_factor ** attempt
                    print(f"Rate limit hit. Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    print(f"Failed with status {response.status_code}")
                    return None
            except Exception as e:
                print(f"Error fetching data: {e}")
            
            attempt += 1
            time.sleep(1)
        
        print("Max retries reached. Failed to fetch data.")
        return None

    def prepare_for_bronze(self, raw_data):
        """
        Wraps raw data into the Bronze schema format (JSON payload + metadata).
        """
        if not raw_data:
            return []
            
        timestamp_received = datetime.now()
        prepared_data = []
        
        for asset in raw_data:
            prepared_data.append({
                "asset_id_raw": asset.get('id'),
                "payload": json.dumps(asset),
                "source": "coincap_api",
                "ingestion_timestamp": timestamp_received
            })
            
        return prepared_data

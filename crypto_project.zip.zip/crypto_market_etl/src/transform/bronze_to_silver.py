from pyspark.sql.functions import from_json, col, current_timestamp, to_timestamp
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType

class BronzeToSilverTransformer:
    """
    Handles transformation of raw Bronze data into clean Silver data.
    """
    
    def __init__(self, spark):
        self.spark = spark
        # Define Schema for JSON API (CoinCap asset object)
        self.api_schema = StructType([
            StructField("id", StringType(), True),
            StructField("rank", StringType(), True),
            StructField("symbol", StringType(), True),
            StructField("name", StringType(), True),
            StructField("supply", StringType(), True),
            StructField("maxSupply", StringType(), True),
            StructField("marketCapUsd", StringType(), True),
            StructField("volumeUsd24Hr", StringType(), True),
            StructField("priceUsd", StringType(), True),
            StructField("changePercent24Hr", StringType(), True),
            StructField("vwap24Hr", StringType(), True)
        ])

    def transform(self, df_bronze):
        """
        Parses JSON payload, casts types, and cleans data.
        """
        # 1. Parse JSON
        df_parsed = df_bronze.withColumn("parsed_data", from_json(col("payload"), self.api_schema)) \
                             .select("ingestion_timestamp", "parsed_data.*")

        # 2. Type Casting & Cleaning
        df_cleaned = df_parsed.select(
            col("id").alias("asset_id"),
            col("rank").cast(IntegerType()).alias("rank"),
            col("symbol"),
            col("name"),
            col("supply").cast(DoubleType()),
            col("maxSupply").cast(DoubleType()),
            col("marketCapUsd").cast(DoubleType()),
            col("volumeUsd24Hr").cast(DoubleType()).alias("volume_usd_24h"),
            col("priceUsd").cast(DoubleType()).alias("price_usd"),
            col("changePercent24Hr").cast(DoubleType()).alias("percent_change_24h"),
            col("vwap24Hr").cast(DoubleType()).alias("vwap_24h"),
            col("ingestion_timestamp")
        )

        # 3. Quality Checks (Filter null keys)
        df_valid = df_cleaned.filter(col("asset_id").isNotNull() & col("price_usd").isNotNull())

        # 4. Add Audit Column
        df_silver = df_valid.withColumn("processed_time", current_timestamp())

        return df_silver

# 🚀 Enterprise Crypto Market ETL + ML & Power BI

A production-ready Data Engineering pipeline that ingests real-time cryptocurrency data, transforms it, and applies **Machine Learning** for asset classification.

## 📂 Project Structure

```
crypto_market_etl/
├── src/
│   ├── extract/          # Bronze Layer (API Connectors)
│   ├── transform/        # Silver Layer (Cleaning)
│   ├── analyze/          # Gold Layer (Aggregations + Stats)
│   └── ml/               # Platinum Layer (K-Means Clustering) [NEW]
├── notebooks/
│   ├── 01_ingest...      
│   ├── 02_transform...   
│   ├── 03_analytics...   
│   ├── 04_ml_advanced    # ML Clustering & Anomaly Detection [NEW]
│   └── 05_powerbi...     # SQL Views for Power BI [NEW]
├── tests/
└── docs/
```

## 🧠 Machine Learning (Platinum Layer)
We use **Spark MLlib** to classify assets into risk profiles:
- **Clustering**: K-Means algorithm groups assets based on Volatility and Market Dominance.
- **Anomaly Detection**: Z-Score analysis to flag "Black Swan" price events (> 3 Sigma).

## 📊 Power BI Integration
The `notebooks/05_powerbi_modeling` script creates a **Star Schema** optimized for reporting:
- **`Fact_Market_History`**: Daily price/volume.
- **`Fact_Anomalies`**: Detected anomalies.
- **`Dim_Asset`**: Asset metadata enriched with ML Cluster IDs.

### How to Connect Power BI
1. Run `notebooks/05_powerbi_modeling` in Databricks.
2. Open Power BI Desktop -> Get Data -> Azure Databricks.
3. Import the views created above.
4. Build your dashboard!

## 🛠 Execution
1. Run Notebooks 01-03 (Standard ETL).
2. Run Notebook 04 (ML & Stats).
3. Run Notebook 05 (Power BI Views).

For detailed setup instructions:
- **Git Integration (Recommended)**: [Databricks Execution Guide](docs/06_databricks_guide.md)
- **Manual Upload (No Git)**: [Manual Databricks Guide](docs/07_manual_databricks_guide.md)
